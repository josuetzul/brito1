﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Semana13_JDTG_1067123_TSJ
{
    internal class Persona
    {
        string nombre, apellido;
        int edad;
        double altura;

        public Persona(string elNombre, string elApellido, int laEdad, double laAltura)
        {
            nombre = elNombre;
            apellido = elApellido;
            edad = laEdad;
            altura = laAltura;
        }
        public void NombreCompleto()
        {
            string nombre_completo = nombre + " " + apellido;
            Console.WriteLine("Nombre: " + nombre_completo);
        }

        public void Alturaenmt()
        {
            double alturaenmt = altura / 100.0;
            Console.WriteLine($"La altura en metros es {alturaenmt}");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Josué Daniel Tzul Gochez - 1067123 - sección 17\n");

            string nombre = "";
            string apellido = "";
            int edad = 0;
            double altura = 0;
            int filas = 0;
            int columnas = 0;

            try
            {
                Console.WriteLine("1. Personas");
                Console.WriteLine("2. Matrices");
                int opcion = Convert.ToInt32(Console.ReadLine());
                if (opcion != 1 && opcion != 2)
                {
                    throw new Exception("Ingrese una opción válida");
                }

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Ingrese el nombre");
                        nombre = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Ingrese el apellido");
                        apellido = Convert.ToString(Console.ReadLine());
                        Console.WriteLine("Ingrese la edad");
                        edad = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese la altura en cm");
                        altura = Convert.ToDouble(Console.ReadLine());

                        Persona persona = new Persona(nombre, apellido, edad, altura);
                        Console.Clear();
                        persona.NombreCompleto();
                        persona.Alturaenmt();

                        Console.ReadKey();
                        break;
                    case 2:
                        Console.WriteLine("Ingrese las filas de la matriz (horizontal)");
                        filas = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese las columnas de la matriz (vertical)");
                        columnas = Convert.ToInt32(Console.ReadLine());

                        int[,] matriz = new int[filas, columnas];

                        int x = 1;
                        int y = 1;
                        int z = 0;
                        for (int i = 0; i < filas; i++)
                        {
                            x = 1;
                            for (int j = 0; j < columnas; j++)
                            {
                                z = x * y;
                                matriz[i, j] = z;
                                Console.Write(matriz[i, j] + "\t");
                                x++;
                            }
                            Console.WriteLine("\n");
                            y++;
                        }
                        
                        break;
                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
